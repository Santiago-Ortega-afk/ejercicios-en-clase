/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>//definicion de biblioteca
#include<math.h>
#define pi 3.1416//definición de la constante pi

void main()//definicion de la funcion principal
{//inicio
    float radio,area;
    printf("ingrese el radio");
    scanf("%f",&radio);//lectura de la variable radio
    //area=pi*radio*radio;//proceso
    area=pi*pow(radio,2);
    printf("El area es %.f",area);//Salida delnvalor de la varible area
}//fin
